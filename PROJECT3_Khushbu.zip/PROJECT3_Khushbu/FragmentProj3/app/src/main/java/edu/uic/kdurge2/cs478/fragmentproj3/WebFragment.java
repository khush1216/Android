package edu.uic.kdurge2.cs478.fragmentproj3;

import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

import edu.uic.kdurge2.cs478.fragmentproj3.MainActivity;
import edu.uic.kdurge2.cs478.fragmentproj3.R;

/**
 * Created by Khushbu on 10/21/2017.
 */

public class WebFragment extends Fragment {

    WebView wv = null;
    int arrayLength;
    private static int mCurrIndex = -1;
    String url;

    //show the web fragment
    void showQuoteAtIndex(int newIndex) {
        if(newIndex <0 || newIndex >= arrayLength){
            return;
        }
        mCurrIndex = newIndex;
        url = MainActivity.urls[mCurrIndex];
        //Log.i("*****************",url);
        //Load the url
        wv.loadUrl(url);
    }

    int getShownIndex() {
        return mCurrIndex;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Retain the fragment
        this.setRetainInstance(true);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view =  inflater.inflate(R.layout.web_layout,
                container, false);
        //call new Web view client
        ((WebView)view.findViewById(R.id.webView)).setWebViewClient(new WebViewClient());

        return view;


    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        //get the layout
        wv = (WebView) getActivity().findViewById(R.id.webView);
        arrayLength = MainActivity.urls.length;
        showQuoteAtIndex(mCurrIndex);


    }
}





