package edu.uic.kdurge2.cs478.fragmentproj3;

import android.Manifest;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity implements TopFragment.ListSelectionListener{

    //Declare fragment tag
    private static final String TAG_RETAINED_FRAGMENT = "RetainedFragment";
    private static final String TAG_WEB_FRAGMENT = "WebRetainedFrag";

    //store the urls here
    public static String[] urls;

    //initialize top and web fragments
    private WebFragment mWebFragment = new WebFragment();
    private TopFragment mRetainedFragment = new TopFragment();

    //declare fragment manager
    private FragmentManager mFragmentManager;
    private FrameLayout mTitleLayout, mWebLaylout;


    private static final int MATCH_PARENT = LinearLayout.LayoutParams.MATCH_PARENT;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //set action bar
        getSupportActionBar().setTitle("FRAGMENT APPLICATION A1");

        //get the layout ids
        mTitleLayout = (FrameLayout) findViewById(R.id.titles);
        mWebLaylout = (FrameLayout) findViewById(R.id.details);

        urls = getResources().getStringArray(R.array.websites);

        //start fragment transaction
        mFragmentManager = getFragmentManager();
        FragmentTransaction ft = mFragmentManager.beginTransaction();

        //get retained fragment
        mRetainedFragment = (TopFragment) mFragmentManager.findFragmentByTag(TAG_RETAINED_FRAGMENT);
        mWebFragment = (WebFragment) mFragmentManager.findFragmentByTag(TAG_WEB_FRAGMENT);

        //if top fragment is null
        if(mRetainedFragment == null) {

            mRetainedFragment = new TopFragment();
            ft.replace(R.id.titles,mRetainedFragment,TAG_RETAINED_FRAGMENT);
            ft.commit();
        }

        //if top fragment is retained
        else{
            ft.replace(R.id.titles,mRetainedFragment,TAG_RETAINED_FRAGMENT);
            ft.commit();

            //if web fragment is null
            if(mWebFragment == null){
                //create new instance
                mWebFragment = new WebFragment();
            }
            //if a web fragment was retained
            else{
                //if Web fragment was not already added , start new transaction
                if(!mWebFragment.isAdded()){
                    FragmentTransaction ft2 = mFragmentManager.beginTransaction();
                    ft2.replace(R.id.details,mWebFragment,TAG_WEB_FRAGMENT);
                    ft2.addToBackStack(null);
                    ft2.commit();

                    //commit all pending transactions
                    mFragmentManager.executePendingTransactions();
                }
            }
        }

        if(mWebFragment == null){
            mWebFragment = new WebFragment();
        }

        mFragmentManager
                .addOnBackStackChangedListener(new FragmentManager.OnBackStackChangedListener() {
                    public void onBackStackChanged() {
                        //set the layout
                        setLayout();
                    }
                });

    }


    private void setLayout() {

        if (!mWebFragment.isAdded()) {

            // Make the Top Fragment occupy the entire layout
            mTitleLayout.setLayoutParams(new LinearLayout.LayoutParams(
                    MATCH_PARENT, MATCH_PARENT));
            mWebLaylout.setLayoutParams(new LinearLayout.LayoutParams(0,
                    MATCH_PARENT));
        } else {

            if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {

                // Make the Top Fragment occupy 1/3 of the layout's width
                mTitleLayout.setLayoutParams(new LinearLayout.LayoutParams(0,
                        MATCH_PARENT, 1f));

                // Make the Web fragment take 2/3's of the layout's width
                mWebLaylout.setLayoutParams(new LinearLayout.LayoutParams(0,
                        MATCH_PARENT, 2f));
            }

            else{
                //if in portrait mode, make the web fragment occupy the entire screen
                mTitleLayout.setLayoutParams(new LinearLayout.LayoutParams(
                        0, MATCH_PARENT));
                mWebLaylout.setLayoutParams(new LinearLayout.LayoutParams(MATCH_PARENT,
                        MATCH_PARENT));

            }
        }
    }


    @Override
    public void onListSelection(int index) {

        //override the Listener method
        //start a new transaction and add the web fragment if not already added
        if (mWebFragment == null || !mWebFragment.isAdded()) {

            FragmentTransaction ft = mFragmentManager.beginTransaction();


            ft.replace(R.id.details,
                    mWebFragment,TAG_WEB_FRAGMENT);

            ft.addToBackStack(null);

            ft.commit();
            mFragmentManager.executePendingTransactions();

        }
        if (mWebFragment.getShownIndex() != index) {

            // Tell the WebFragment to show the web view at position index
            mWebFragment.showQuoteAtIndex(index);

        }
    }

    //create the options menu
    public boolean onCreateOptionsMenu(Menu menu){

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.options_menu, menu);
        return true;
    }

    //for every option in the menu
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            //exit the app and show the home screen
            case R.id.exit:
                Intent intent = new Intent(Intent.ACTION_MAIN);
                intent.addCategory(Intent.CATEGORY_HOME);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                return true;
            //Launch Gallery app A2 using a broadcast receiver
            case R.id.launchA2:
                //Request permission at run time
                if(ContextCompat.checkSelfPermission(this,"edu.uic.kdurge2.cs478.permission.MYFIRSTPERM") != PackageManager.PERMISSION_GRANTED){

                    ActivityCompat.requestPermissions(this, new String[] {"edu.uic.kdurge2.cs478.permission.MYFIRSTPERM"},0);

                }
                //if permission already granted, start APP A2
                else {
                    startApp2();
                }
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    //Starting new app by sending a broadcast
    public void startApp2(){

        Intent i = new Intent();
        i.setAction("edu.uic.kdurge2.cs478.launchA2");
        i.addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES);
        sendBroadcast(i);
       // Log.i("%%%%%%%Afterlaunch%%%", "%%%%%Afterlaunch%%");
    }

    @Override
    protected void onStart(){
        super.onStart();
        //override on start to check for retained fragments when the app starts
        setLayout();
        Log.i("***index***",String.valueOf(mRetainedFragment.mIndex));
        mWebFragment.showQuoteAtIndex(mRetainedFragment.mIndex);

    }


    //when the app A2 grants or declines the permission
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        //if permission granted
        if(grantResults[0] == PackageManager.PERMISSION_GRANTED){

            startApp2();

        }
        //if permission not granted
        else{
            Log.i("","PERMISSION NOT GRANTED");
        }
    }

}
