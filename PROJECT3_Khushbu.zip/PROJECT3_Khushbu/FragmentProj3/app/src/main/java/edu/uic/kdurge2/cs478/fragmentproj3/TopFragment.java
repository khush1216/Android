package edu.uic.kdurge2.cs478.fragmentproj3;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.app.ListFragment;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;

import static android.widget.ListPopupWindow.MATCH_PARENT;

/**
 * Created by Khushbu on 10/22/2017.
 */

public class  TopFragment extends ListFragment {

    //initialize listener
    private ListSelectionListener mListener = null;
    //initialize current index
    int mIndex = -1;

    //need to override this in Main activity
    public interface ListSelectionListener {
        public void onListSelection(int index);
    }

    @Override
    public void onListItemClick(ListView l, View v, int pos, long id) {

        // Indicates the selected item has been checked
        if(mIndex != pos) {
            mIndex = pos;
            mListener.onListSelection(pos);
        }
        // Inform the Web Fragment that the item in position pos has been selected
        getListView().setItemChecked(pos, true);


    }

    @Override
    public void onAttach(Context activity) {
        super.onAttach(activity);

        try {

            // Set the ListSelectionListener for communicating with the MainActivity
            mListener = (ListSelectionListener) activity;

        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement OnArticleSelectedListener");
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //retain the fragment on configuration change
        this.setRetainInstance(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public void onActivityCreated(Bundle savedState) {
        super.onActivityCreated(savedState);

        // Set the list adapter for the ListView
        setListAdapter(new ArrayAdapter<String>(getActivity(),
                R.layout.list_text_view, getResources().getStringArray(R.array.landmark_name)));

        // Set the list choice mode to allow only one selection at a time
        getListView().setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        if(mIndex != -1){
            getListView().setItemChecked(mIndex,true);
        }

    }


}


