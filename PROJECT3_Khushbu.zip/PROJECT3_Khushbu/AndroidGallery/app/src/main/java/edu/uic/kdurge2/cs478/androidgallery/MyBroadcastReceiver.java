package edu.uic.kdurge2.cs478.androidgallery;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

/**
 * Created by Khushbu on 10/25/2017.
 */

public class MyBroadcastReceiver extends BroadcastReceiver {

    //Override onReceive method of broadcast receiver to receive broadcast
    public void onReceive(Context context, Intent intent){

        Log.i("here","###############STARTED##########");

        Intent i = new Intent(context, MainActivity.class);
        context.startActivity(i);

    }
}
