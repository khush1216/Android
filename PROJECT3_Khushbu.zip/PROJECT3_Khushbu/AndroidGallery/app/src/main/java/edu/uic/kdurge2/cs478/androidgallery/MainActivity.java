package edu.uic.kdurge2.cs478.androidgallery;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    //stores the list names
    private final String image_titles[] = {
            "BEAN",
            "FOUNTAIN",
            "ZOO",
            "WILLIS",
            "BEAN",
            "ZOO",
            "WILLIS",
            "WRIGLY FIELD",
            "SHEDD AQUARIUM",
            "SHEDD AQUARIUM",
            "WRIGLY FIELD",
            "BEAN"

                };

    //stores drawable ids
    private final Integer image_ids[] = {
            R.drawable.bean,
            R.drawable.fountain,
            R.drawable.zoo,
            R.drawable.willis,
            R.drawable.bean2,
            R.drawable.zoo2,
            R.drawable.willis2,
            R.drawable.shedd,
            R.drawable.wrigly,
            R.drawable.shedd2,
            R.drawable.wrigly2,
            R.drawable.bean3

    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //set the action bar
        getSupportActionBar().setTitle("GALLERY APPLICATION A2");

        //set recycler view - does not cause problem with scrolling
        RecyclerView recyclerView = (RecyclerView)findViewById(R.id.imagegallery);
        recyclerView.setHasFixedSize(true);

        RecyclerView.LayoutManager layoutManager = new GridLayoutManager(getApplicationContext(),2);
        recyclerView.setLayoutManager(layoutManager);
        //set the custom adapter for recycler view
        CustomAdapter adapter = new CustomAdapter(getApplicationContext(), image_titles, image_ids);

        //adapt to recycler view
        recyclerView.setAdapter(adapter);
    }
}

