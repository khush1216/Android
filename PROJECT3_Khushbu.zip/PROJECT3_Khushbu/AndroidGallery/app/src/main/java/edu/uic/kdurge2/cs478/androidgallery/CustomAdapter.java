package edu.uic.kdurge2.cs478.androidgallery;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by Khushbu on 10/24/2017.
 */

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.ViewHolder>  {

    //decare class variables
    private Context context;
    private String[] image_titles;
    private Integer[] imageIDS;

    //Adapter constructor
    public CustomAdapter(Context context, String[] image_titles, Integer[] imageIDS){
        this.context = context;
        this.image_titles = image_titles;
        this.imageIDS = imageIDS;
    }

    @Override
    public void onBindViewHolder(CustomAdapter.ViewHolder viewHolder, int i) {
        //set the view and images
        viewHolder.img.setScaleType(ImageView.ScaleType.CENTER_CROP);
        viewHolder.img.setImageResource(imageIDS[i]);
        viewHolder.title.setText(image_titles[i]);

    }

    @Override
    public int getItemCount() {
        return imageIDS.length;
    }


    @Override
    public CustomAdapter.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        //inflate view
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.adapter_layout, viewGroup, false);
        return new ViewHolder(view);
    }
    public class ViewHolder extends RecyclerView.ViewHolder {

        //nested class uses view holder method
        private ImageView img;
        private TextView title;

        public ViewHolder(View view) {
            super(view);
            //set the title and images
            title = (TextView)view.findViewById(R.id.title);
            img = (ImageView) view.findViewById(R.id.img);
        }
    }

}
