//package edu.uic.kdurge2.cs478.guessfour;
//
//import android.support.annotation.LayoutRes;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.widget.ScrollView;
//
///**
// * Created by Khushbu on 11/16/2017.
// */
//
//public class ClearScrollView extends ScrollView {
//
//    public void setContent(@LayoutRes int layoutRes) {
//        View view = LayoutInflater.from(getContext()).inflate(layoutRes, this, false);
//        this.addView(view);
//    }
//
//    public void clearContent() {
//        this.removeAllViews();
//    }
//}
