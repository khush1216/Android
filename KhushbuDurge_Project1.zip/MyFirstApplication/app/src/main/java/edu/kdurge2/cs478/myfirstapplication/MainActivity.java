package edu.kdurge2.cs478.myfirstapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.view.ViewPropertyAnimatorCompatSet;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button butn1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i("Main Activity","Khushbu Durge was here !");
        setContentView(R.layout.activity_main);
        //Log.i("Main Activity","Khushbu Durge was here !");

        butn1 = (Button)findViewById(R.id.buttonMain);

        butn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this,ContactActivity.class);
                startActivity(i);

            }
        });

    }



   /*public void onButtonMainClick(View view){

        if(view.getId() == R.id.buttonMain) {
            Intent i = new Intent(this, ContactActivity.class);
            startActivity(i);
        }


    }*/
}
