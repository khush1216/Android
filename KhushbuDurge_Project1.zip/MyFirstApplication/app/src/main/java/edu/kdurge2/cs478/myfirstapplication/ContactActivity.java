package edu.kdurge2.cs478.myfirstapplication;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static android.R.attr.data;

/**
 * Created by Khushbu on 9/16/2017.
 * Check for empty spaces in the beginning.
 */

public class ContactActivity extends Activity {

    EditText inpName;
    Button addContact;
    TextView displayTxt;
    static final int SENT_REQ_CODE =1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //Log.i("ContactActivity", "I'm in second");
        super.onCreate(savedInstanceState);
        Log.i("Contact Activity","this is inside Activity 2!");
        setContentView(R.layout.contactxml);

        inpName = (EditText)findViewById(R.id.inputName);
        addContact = (Button)findViewById(R.id.addButton);
        displayTxt = (TextView)findViewById(R.id.readOnlytxt);


        addContact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

               /* Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT,inpName.getText().toString());
                sendIntent.setType("text/plain");

                if(sendIntent.resolveActivity(getPackageManager()) != null){
                    startActivity(sendIntent);
                }*/
                //Intent intentInsertEdit = new Intent(ContactsContract.Intents.Insert.ACTION);
                //intentInsertEdit.setType(ContactsContract.RawContacts.CONTENT_TYPE);
                Intent intentInsertEdit = new Intent(Intent.ACTION_INSERT);
                intentInsertEdit.setType(ContactsContract.Contacts.CONTENT_TYPE);


                if(TextUtils.isEmpty(inpName.getText().toString())){
                    displayTxt.setText("You have entered an empty string!");
                    //Log.i("Contact Activity","I'm HERE!!!******");
                    return;
                }

                Pattern p = Pattern.compile("\\s*[a-zA-Z0-9]+\\s+[a-zA-Z0-9]+\\s*");
                Matcher m = p.matcher(inpName.getText().toString());
                boolean b = m.matches();

                if( ! b){
                    displayTxt.setText("You have not entered the First or Last Name!");
                    return;
                }
                /*String[] WC = inpName.getText().toString().split("\\s+");

                if(!(WC.length >= 2)){
                   Log.i("DISPLAY NAME", inpName.getText().toString());
                    displayTxt.setText("You have not entered the First or Last Name!");
                    return;
                }*/

                //else {
                    //Log.i("Contact Activity","should not display this******");
                    intentInsertEdit.putExtra(ContactsContract.Intents.Insert.NAME, inpName.getText().toString());//Toast.makeText("You have not entered a name!", Toast.LENGTH_SHORT).show();
                    if (Integer.valueOf(Build.VERSION.SDK) > 14)
                        intentInsertEdit.putExtra("finishActivityOnSaveCompleted", true);
               // }
               startActivityForResult(intentInsertEdit,SENT_REQ_CODE);

            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode,int resultCode, Intent data){
        if(requestCode == SENT_REQ_CODE){
            if(resultCode == RESULT_OK){
                Log.i("","RESULT OK!!!!!!!!!");
                displayTxt.setText("Your contact was saved!");
            }
            else{
                Log.i("SECOND*******RESULT", String.valueOf(resultCode));
                displayTxt.setText("Did not save new contact!");
            }


        }

    }


}
