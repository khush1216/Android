package edu.uic.kdurge2.cs478.treasuryserv;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

  //  ArrayList<Boolean> statusList = new ArrayList<Boolean>();
    TextView status1,status2,status3,status4;

    TreasuryServe treasuryServe = new TreasuryServe();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        status1 = (TextView) findViewById(R.id.status1);
        status2 = (TextView) findViewById(R.id.status2);
        status3 = (TextView) findViewById(R.id.status3);
        status4 = (TextView) findViewById(R.id.status4);

       // statusList = treasuryServe.getServiceStatus();
        //1 = service unbound
        //2 = service bound but idle
        //3 = service bound and running
        //4 = service destroyed

    }


    @Override
    public void onResume(){

        //statusList = treasuryServe.getServiceStatus();



        if(TreasuryServe.SERVICE_NOT_BOUND){

            status1.setBackgroundResource(R.color.colorAccent);
            status2.setBackgroundResource(R.color.colorWhite);
            status3.setBackgroundResource(R.color.colorWhite);
            status4.setBackgroundResource(R.color.colorWhite);

        }
        if(TreasuryServe.SERVICE_BOUND_IDLE){
            status2.setBackgroundResource(R.color.colorAccent);
            status1.setBackgroundResource(R.color.colorWhite);
            status3.setBackgroundResource(R.color.colorWhite);
            status4.setBackgroundResource(R.color.colorWhite);



        }
        if(TreasuryServe.SERVICE_BOUND_RUNNING){
            status3.setBackgroundResource(R.color.colorAccent);
            status1.setBackgroundResource(R.color.colorWhite);
            status2.setBackgroundResource(R.color.colorWhite);
            status4.setBackgroundResource(R.color.colorWhite);


        }

        if(TreasuryServe.SERVICE_DESTROYED){
            status4.setBackgroundResource(R.color.colorAccent);
            status1.setBackgroundResource(R.color.colorWhite);
            status2.setBackgroundResource(R.color.colorWhite);
            status3.setBackgroundResource(R.color.colorWhite);

        }

        super.onResume();




    }



}
