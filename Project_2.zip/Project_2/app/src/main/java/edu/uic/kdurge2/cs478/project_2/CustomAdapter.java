package edu.uic.kdurge2.cs478.project_2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by Khushbu on 10/2/2017.
 */

public class CustomAdapter extends BaseAdapter {

    ArrayList<String> listItem;
    ArrayList<String> listAddress;

    Context mContext;
    //constructor
    public CustomAdapter(Context mContext, ArrayList<String> listItem, ArrayList<String> listAddress) {
        this.mContext = mContext;
        this.listItem = listItem;
        this.listAddress = listAddress;
    }

    public int getCount() {
        return listItem.size();
    }

    public Object getItem(int arg0) {
        return null;
    }

    public long getItemId(int position) {
        return position;
    }

    public View getView(int position, View arg1, ViewGroup viewGroup) {
        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View row = inflater.inflate(R.layout.listdesign, viewGroup, false);

        TextView nameText = (TextView) row.findViewById(R.id.name);
        TextView addressText = (TextView) row.findViewById(R.id.address);

        nameText.setText(listItem.get(position));
        addressText.setText(listAddress.get(position));


        return row;
    }
}
