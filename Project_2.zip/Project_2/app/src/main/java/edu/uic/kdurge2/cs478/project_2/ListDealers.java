package edu.uic.kdurge2.cs478.project_2;

import android.app.ListActivity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ListDealers extends AppCompatActivity {

    String [] names;
    String [] addresses;

    ListView my_list;
    private SimpleAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_dealers);

        Intent receive = getIntent();
        names = receive.getStringArrayExtra("Names");
        addresses = receive.getStringArrayExtra("Address");

        ArrayList<String> name = new ArrayList<String>(Arrays.asList(names));
        ArrayList<String> addr = new ArrayList<String>(Arrays.asList(addresses));

        //ListAdapter myListAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,stringArray);

        ListView myListView =  (ListView)findViewById(R.id.mobile_list);


        myListView.setAdapter(new CustomAdapter(this,name,addr));
    }



    /*public ArrayList<List<String>> getArrayList(String[] names, String[] address){

        ArrayList<List<String>> res = new ArrayList<>();
        List<String> pair = new ArrayList<>();
        for(int i=0;i>names.length; i++){
            pair.add(names[i]);
            pair.add(address[i]);

            res.add(pair);
            pair.clear();
        }
        return res;
    }*/

}
