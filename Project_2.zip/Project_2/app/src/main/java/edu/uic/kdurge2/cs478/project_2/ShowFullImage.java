package edu.uic.kdurge2.cs478.project_2;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class ShowFullImage extends AppCompatActivity {

    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_full_image);

        imageView = (ImageView) findViewById(R.id.imageV);
        int posit = getIntent().getIntExtra("id", 0);


        final Intent i2 = new Intent(Intent.ACTION_VIEW);
        i2.addCategory(Intent.CATEGORY_BROWSABLE);

        switch (posit) {
            case 0:
                imageView.setImageResource(R.drawable.sample_0);
                i2.setData(Uri.parse("https://www.bmwusa.com/"));
                break;
            case 1:
                imageView.setImageResource(R.drawable.sample_1);
                i2.setData(Uri.parse("https://www.jaguarusa.com/index.html"));
                break;
            case 2:
                imageView.setImageResource(R.drawable.sample_2);
                i2.setData(Uri.parse("https://www.nissanusa.com/"));
                break;
            case 3:
                imageView.setImageResource(R.drawable.sample_3);
                i2.setData(Uri.parse("https://www.mercedes-benz.com/en/"));
                break;
            case 4:
                imageView.setImageResource(R.drawable.sample_4);
                i2.setData(Uri.parse("http://www.honda.com/"));
                break;
            case 5:
                imageView.setImageResource(R.drawable.sample_5);
                i2.setData(Uri.parse("https://www.ferrari.com/en-US"));
                break;
            case 6:
                imageView.setImageResource(R.drawable.sample_6);
                i2.setData(Uri.parse("https://www.audiusa.com/"));
                break;
            case 7:
                imageView.setImageResource(R.drawable.sample_7);
                i2.setData(Uri.parse("https://www.bentleymotors.com/en.html"));
                break;
            case 8:
                imageView.setImageResource(R.drawable.sample_8);
                i2.setData(Uri.parse("https://www.bugatti.com/home/"));
                break;
            case 9:
                imageView.setImageResource(R.drawable.sample_9);
                i2.setData(Uri.parse("https://www.acura.com/"));
                break;
            case 10:
                imageView.setImageResource(R.drawable.sample_10);
                i2.setData(Uri.parse("https://www.toyota.com/corolla/"));
                break;
            case 11:
                imageView.setImageResource(R.drawable.sample_11);
                i2.setData(Uri.parse("https://www.rolls-roycemotorcars.com/"));
                break;



        }

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(i2);
            }
        });




    }
}

