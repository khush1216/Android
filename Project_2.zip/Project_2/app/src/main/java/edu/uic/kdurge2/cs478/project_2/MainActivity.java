package edu.uic.kdurge2.cs478.project_2;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.Image;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;

public class MainActivity extends AppCompatActivity {

    Context context;
    GridView gridView;
    ImageView currImage;

    static final String[] MOBILE_OS = new String[] {
            "BMW", "Jaguar","Altima", "Mercedes", "Honda", "Ferrari", "Audi", "Bentley", "Bugatti", "Acura", "Corolla", "Rolls Royce" };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        gridView = (GridView) findViewById(R.id.gridView);
        gridView.setAdapter(new ImageAdapter(this, MOBILE_OS));

       registerForContextMenu(gridView);

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {


                Intent i = new Intent(getApplicationContext(), ShowFullImage.class);
                // passing array index
                Log.i("******POSITION******", "POSITION =" + position);
                i.putExtra("id", position);
                startActivity(i);
            }
        });




    }
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo){
        super.onCreateContextMenu(menu,v,menuInfo);

        getMenuInflater().inflate(R.menu.menu_main, menu);


    }

    @Override
    public boolean onContextItemSelected(MenuItem item){

        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        int index = info.position;
        //Log.i("******POSITION******", "POSITION =" + index);


        switch (item.getItemId()){
            case R.id.option_1:
                Intent int1 = new Intent(getApplicationContext(), ShowFullImage.class);
                int1.putExtra("id", index);
                startActivity(int1);
                break;
            case R.id.option_2:
                Intent int2 = new Intent(Intent.ACTION_VIEW);
                int2.addCategory(Intent.CATEGORY_BROWSABLE);

                switch (index){
                    case 0:
                        int2.setData(Uri.parse("https://www.bmwusa.com/"));
                        startActivity(int2);
                        break;
                    case 1:
                        int2.setData(Uri.parse("https://www.jaguarusa.com/index.html"));
                        startActivity(int2);
                        break;
                    case 2:
                        int2.setData(Uri.parse("https://www.nissanusa.com/"));
                        startActivity(int2);
                        break;
                    case 3:
                        int2.setData(Uri.parse("https://www.mercedes-benz.com/en/"));
                        startActivity(int2);
                        break;
                    case 4:
                        int2.setData(Uri.parse("http://www.honda.com/"));
                        startActivity(int2);
                        break;
                    case 5:
                        int2.setData(Uri.parse("https://www.ferrari.com/en-US"));
                        startActivity(int2);
                        break;
                    case 6:
                        int2.setData(Uri.parse("https://www.audiusa.com/"));
                        startActivity(int2);
                        break;
                    case 7:
                        int2.setData(Uri.parse("https://www.bentleymotors.com/en.html"));
                        startActivity(int2);
                        break;
                    case 8:
                        int2.setData(Uri.parse("https://www.bugatti.com/home/"));
                        startActivity(int2);
                        break;
                    case 9:
                        int2.setData(Uri.parse("https://www.acura.com/"));
                        startActivity(int2);
                        break;
                    case 10:
                        int2.setData(Uri.parse("https://www.toyota.com/corolla/"));
                        startActivity(int2);
                        break;
                    case 11:
                        int2.setData(Uri.parse("https://www.rolls-roycemotorcars.com/"));
                        startActivity(int2);
                        break;

                }

               // Toast.makeText(this, item.toString(),Toast.LENGTH_LONG).show();
                break;
            case R.id.option_3:
                Intent int3 = new Intent(this, ListDealers.class);
                Bundle extrasB = new Bundle();

                switch (index){
                    case 0:
                        extrasB.putStringArray("Names",getResources().getStringArray(R.array.bmw_dealer));
                        extrasB.putStringArray("Address",getResources().getStringArray(R.array.bmw_addr));
                        int3.putExtras(extrasB);
                        //int3.putExtra("string-array",getResources().getStringArray(R.array.bmw_dealer));
                        startActivity(int3);
                        break;
                    case 1:
                        extrasB.putStringArray("Names",getResources().getStringArray(R.array.jaguar_dealer));
                        extrasB.putStringArray("Address",getResources().getStringArray(R.array.jaguar_addr));
                        //int3.putExtra("string-array",getResources().getStringArray(R.array.jaguar_dealer));
                        int3.putExtras(extrasB);
                        startActivity(int3);
                        break;
                    case 2:
                        extrasB.putStringArray("Names",getResources().getStringArray(R.array.altima_dealer));
                        extrasB.putStringArray("Address",getResources().getStringArray(R.array.altima_addr));
                        //int3.putExtra("string-array",getResources().getStringArray(R.array.jaguar_dealer));
                        int3.putExtras(extrasB);
                        startActivity(int3);
                        break;
                    case 3:
                        extrasB.putStringArray("Names",getResources().getStringArray(R.array.merc_dealer));
                        extrasB.putStringArray("Address",getResources().getStringArray(R.array.merc_addr));
                        //int3.putExtra("string-array",getResources().getStringArray(R.array.jaguar_dealer));
                        int3.putExtras(extrasB);
                        startActivity(int3);
                        break;
                    case 4:
                        extrasB.putStringArray("Names",getResources().getStringArray(R.array.honda_dealer));
                        extrasB.putStringArray("Address",getResources().getStringArray(R.array.honda_addr));
                        //int3.putExtra("string-array",getResources().getStringArray(R.array.jaguar_dealer));
                        int3.putExtras(extrasB);
                        startActivity(int3);
                        break;
                    case 5:
                        extrasB.putStringArray("Names",getResources().getStringArray(R.array.ferrari_dealer));
                        extrasB.putStringArray("Address",getResources().getStringArray(R.array.ferrari_addr));
                        int3.putExtras(extrasB);
                        //int3.putExtra("string-array",getResources().getStringArray(R.array.bmw_dealer));
                        startActivity(int3);
                        break;
                    case 6:
                        extrasB.putStringArray("Names",getResources().getStringArray(R.array.audi_dealer));
                        extrasB.putStringArray("Address",getResources().getStringArray(R.array.audi_addr));
                        int3.putExtras(extrasB);
                        //int3.putExtra("string-array",getResources().getStringArray(R.array.bmw_dealer));
                        startActivity(int3);
                        break;
                    case 7:
                        extrasB.putStringArray("Names",getResources().getStringArray(R.array.bentley_dealer));
                        extrasB.putStringArray("Address",getResources().getStringArray(R.array.bentley_addr));
                        int3.putExtras(extrasB);
                        //int3.putExtra("string-array",getResources().getStringArray(R.array.bmw_dealer));
                        startActivity(int3);
                        break;
                    case 8:
                        extrasB.putStringArray("Names",getResources().getStringArray(R.array.bugatti_dealer));
                        extrasB.putStringArray("Address",getResources().getStringArray(R.array.bugatti_addr));
                        int3.putExtras(extrasB);
                        //int3.putExtra("string-array",getResources().getStringArray(R.array.bmw_dealer));
                        startActivity(int3);
                        break;
                    case 9:
                        extrasB.putStringArray("Names",getResources().getStringArray(R.array.acura_dealer));
                        extrasB.putStringArray("Address",getResources().getStringArray(R.array.acura_addr));
                        int3.putExtras(extrasB);
                        //int3.putExtra("string-array",getResources().getStringArray(R.array.bmw_dealer));
                        startActivity(int3);
                        break;
                    case 10:
                        extrasB.putStringArray("Names",getResources().getStringArray(R.array.corolla_dealer));
                        extrasB.putStringArray("Address",getResources().getStringArray(R.array.corolla_addr));
                        int3.putExtras(extrasB);
                        //int3.putExtra("string-array",getResources().getStringArray(R.array.bmw_dealer));
                        startActivity(int3);
                        break;
                    case 11:
                        extrasB.putStringArray("Names",getResources().getStringArray(R.array.rollsRoyce_dealer));
                        extrasB.putStringArray("Address",getResources().getStringArray(R.array.rolls_addr));
                        int3.putExtras(extrasB);
                        //int3.putExtra("string-array",getResources().getStringArray(R.array.bmw_dealer));
                        startActivity(int3);
                        break;

                }

               // Toast.makeText(this, item.toString(),Toast.LENGTH_LONG).show();
                break;
        }
        return super.onContextItemSelected(item);
    }


    }




