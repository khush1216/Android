package edu.uic.kdurge2.cs478.project_2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;


/**
 * Created by Khushbu on 10/1/2017.
 */

public class ImageAdapter extends BaseAdapter {

    public ImageView imgView;

    private Context context;
    private final String[] mobileValues;

    public ImageAdapter(Context context, String[] mobileValues) {
        this.context = context;
        this.mobileValues = mobileValues;
    }


    public View getView(int position, View convertView, ViewGroup parent) {

        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View gridView;

        if (convertView == null) {

            gridView = new View(context);

            // get layout from mobile.xml
            gridView = inflater.inflate(R.layout.mobile, null);

            // set value into textview
            TextView textView = (TextView) gridView
                    .findViewById(R.id.grid_item_label);
            textView.setText(mobileValues[position]);

            // set image based on selected text
            ImageView imageView = (ImageView) gridView
                    .findViewById(R.id.grid_item_image);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(300, 300);
            imageView.setLayoutParams(layoutParams);
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            String mobile = mobileValues[position];

            if (mobile.equals("BMW")) {
                imageView.setImageResource(R.drawable.sample_0);
            } else if (mobile.equals("Jaguar")) {
                imageView.setImageResource(R.drawable.sample_1);
            } else if (mobile.equals("Altima")) {
                imageView.setImageResource(R.drawable.sample_2);
            }
            else if (mobile.equals("Mercedes")) {
                imageView.setImageResource(R.drawable.sample_3);
            }
            else if (mobile.equals("Honda")) {
                imageView.setImageResource(R.drawable.sample_4);
            }
            else if (mobile.equals("Ferrari")) {
                imageView.setImageResource(R.drawable.sample_5);
            }
            else if (mobile.equals("Audi")) {
                imageView.setImageResource(R.drawable.sample_6);
            }
            else if (mobile.equals("Bentley")) {
                imageView.setImageResource(R.drawable.sample_7);
            }
            else if (mobile.equals("Bugatti")) {
                imageView.setImageResource(R.drawable.sample_8);
            }
            else if (mobile.equals("Acura")) {
                imageView.setImageResource(R.drawable.sample_9);
            }
            else if (mobile.equals("Corolla")) {
                imageView.setImageResource(R.drawable.sample_10);
            }
            else {
                imageView.setImageResource(R.drawable.sample_11);

            }
            imgView = imageView;
        } else {
            gridView = (View) convertView;
        }


        return gridView;
    }

    public ImageView getCurrImage(){
        return imgView;
    }

    @Override
    public int getCount() {
        return mobileValues.length;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

}


